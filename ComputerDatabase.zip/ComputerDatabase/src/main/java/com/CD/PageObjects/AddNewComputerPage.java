package com.CD.PageObjects;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import Resources.Base;

public class AddNewComputerPage extends Base{
	
	@FindBy(id="name")
	WebElement computerName;
	
	@FindBy(id="introduced")
	WebElement introduced;
	
	@FindBy(id="discontinued")
	WebElement discontinued;
	
	@FindBy(id="company")
	WebElement company;
	
	@FindBy(xpath="//*[@type='submit']")
	WebElement create;
	
	@FindBy(xpath="//*[@class='btn']")
	WebElement cancel;
	
	@FindBy(xpath="//*[@class='clearfix error']")
	public WebElement errorMsg;
	


	public AddNewComputerPage() {
		PageFactory.initElements( driver, this); 
		
	}


	


	public String validatePageTitle() {
		return driver.getTitle();
	}

	
	public void validateDateInAddNewComputer()
	{
		computerName.sendKeys("ABC");
		introduced.sendKeys("sdf");
		discontinued.sendKeys("09-09-1994");
		Select s =new Select(company);
		s.selectByVisibleText("IBM");
		create.click();
		
	}
	

	public void addNewComputer()
	{
		computerName.sendKeys("ABC");
		introduced.sendKeys("");
		discontinued.sendKeys("");
		Select s =new Select(company);
		s.selectByVisibleText("IBM");
		create.click();
		
	}
	
	static Workbook book;
	static Sheet sheet;
	
	
    String sheetName = "addNew";
    
	
	public static Object[][] getTestData(String sheetName) throws Exception
    {
        
        FileInputStream file=new FileInputStream("/Users/vamsee/eclipse-workspaceNew/ComputerDatabase/src/main/java/Resources/CDTestData.xlsx");
        book=WorkbookFactory.create(file);
        
        sheet=book.getSheet(sheetName);
        Object[][] data=new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
        for(int i=0;i<sheet.getLastRowNum();i++)
        {
        	for (int k=0;k<sheet.getRow(0).getLastCellNum();k++)
        	{
        		data[i][k]=sheet.getRow(i+1).getCell(k).toString();
        	}
        }
        
        return data;
    }

}
