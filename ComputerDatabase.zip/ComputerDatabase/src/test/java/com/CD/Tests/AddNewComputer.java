package com.CD.Tests;

import java.io.IOException;

import org.apache.poi.xdgf.util.Util;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.CD.PageObjects.AddNewComputerPage;
import com.CD.PageObjects.CDMainPage;

import Resources.Base;


public class AddNewComputer extends Base {
	
	CDMainPage cdMainPage;
	AddNewComputerPage addNewPage;
	Util util;
	String sheetName="addNew";
	String introduced;
	String discontinued;
	String company;
	String cname;
	
	public AddNewComputer(){
		
		super();
	}
	
	
	
	@BeforeMethod
	public void initialize() throws IOException
	{
	
		 initializeDriver();
		 cdMainPage=new CDMainPage();
		 addNewPage=new AddNewComputerPage();
		 util=new Util();
	}
	
	@DataProvider
	public Object[][] getAddNewData(String sheetName) throws Exception
	{
	
      Object[][] data = addNewPage.getTestData(sheetName);
        return data;
	}
	
	
    
    
	@Test
	public void addNewComputerTest() throws InterruptedException {
		
		
		
		String name=cdMainPage.validatePageTitle();
		Assert.assertEquals(name,"Computers database");
		System.out.println(cdMainPage.validatePageTitle());
		cdMainPage.addNewClick();
		addNewPage.addNewComputer();
		//addNewPage.addNewComputer(cname, introduced,discontinued,company);
		String msg= cdMainPage.success.getText();
		Assert.assertEquals(msg,"Done ! Computer ABC has been created");
	}
	
	@Test
	public void validateDateInAddNewComputerTest() throws InterruptedException {
		
		
		
		String name=cdMainPage.validatePageTitle();
		Assert.assertEquals(name,"Computers database");
		System.out.println(cdMainPage.validatePageTitle());
		cdMainPage.addNewClick();
		addNewPage.validateDateInAddNewComputer();
		String msg= addNewPage.errorMsg.getText();
		System.out.println(msg);
		Assert.assertTrue(true);
	}
	
	@Test
	public void searchComputerTest()
	{
		cdMainPage.verifySearchBox();
	}
	
	
	
	
	 @AfterMethod 
	 public void afterTear() { 
		 driver.close(); }
	 
	

}
