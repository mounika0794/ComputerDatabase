package com.CD.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Resources.Base;

public class CDMainPage extends Base {
	
	@FindBy(id="add")
	WebElement add;
	
	@FindBy(id="searchbox")
	WebElement search;
	
	@FindBy(id="searchsubmit")
	WebElement submit;
	
	@FindBy(xpath="//*[@class='alert-message warning']")
	public WebElement success;
	
	

	public CDMainPage() {
		PageFactory.initElements( driver, this); 
		
	}


	public String validatePageTitle() {
		return driver.getTitle();
	}


	public AddNewComputerPage addNewClick()
	{
		add.click();
		return new AddNewComputerPage();
	}
	
	
	public void verifySearchBox() {
		search.sendKeys("Acer");
		submit.click();
	}
	

}
