package Resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Base {
	
	public static WebDriver driver;
	public static  Properties prop;


@SuppressWarnings("deprecation")
public static void initializeDriver() throws IOException
{
	
 prop= new Properties();
FileInputStream fis=new FileInputStream("/Users/vamsee/eclipse-workspaceNew/New/data.properties");

prop.load(fis);
String browserName=prop.getProperty("browser");

System.out.println(browserName);

if(browserName.equals("chrome"))
{
	 System.setProperty("webdriver.chrome.driver", "//Users//vamsee//Documents//Work//chromedriver");
	driver= new ChromeDriver();
	
		//execute in chrome driver
	
}
else if (browserName.equals("firefox"))
{
	System.setProperty("webdriver.gecko.driver", "//Users//vamsee//Documents//Work//geckodriver");
	driver= new FirefoxDriver();
	//firefox code
}
else if (browserName.equals("IE"))
{
//	IE code
}



driver.manage().deleteAllCookies();
driver.get(prop.getProperty("url"));
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

}

}
